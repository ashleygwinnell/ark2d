------------------------------------------------------------

HOT CROSS BUNIONS!                  

------------------------------------------------------------

## INTRO

Collect ingredients that fall from the top of the screen
with your cauldron to make foul breakfasts for the wicked
witch. With local highscores, compete against your friends
for super awesome fun times.


## CONTROLS

A and D, or arrow keys to move.
F4 for (broken) fullscreen mode.


## CONTACT

Email:    info@ashleygwinnell.co.uk

Website:  http://www.ashleygwinnell.co.uk/


------------------------------------------------------------

(c) Ashley Gwinnell 2011

------------------------------------------------------------